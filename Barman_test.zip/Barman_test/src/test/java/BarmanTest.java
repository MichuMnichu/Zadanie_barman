import org.example.Barman;
import org.example.Drink;
import org.example.Ingredient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class BarmanTest {

    private Barman barman;
    private List<Ingredient> ingredients;

    @BeforeEach
    public void setUp() {
        barman = new Barman();
        ingredients = new ArrayList<>();
        ingredients.add(new Ingredient("Woda", "50ml"));
        ingredients.add(new Ingredient("Sok", "100ml"));
    }

    @Test
    public void testCreateDrink() {
        Drink drink = barman.createDrink(ingredients);
        assertEquals(2, drink.getIngredients().size());
    }

    @Test
    public void testPrintDrink() {
            }
}