package org.example;

import java.util.List;

public class Barman {

    public Drink createDrink(List<Ingredient> ingredients) {
        return new Drink(ingredients);
    }

    public void printDrink(Drink drink) {
        System.out.println("Drink details:");
        for (Ingredient ingredient : drink.getIngredients()) {
            System.out.println(ingredient.getName() + " - " + ingredient.getAmount());
        }
    }
}