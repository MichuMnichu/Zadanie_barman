package org.example;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Barman barman = new Barman();
        List<Ingredient> ingredients = chooseIngredients();

        Drink drink = barman.createDrink(ingredients);
        barman.printDrink(drink);
    }

    public static List<Ingredient> chooseIngredients() {
        List<Ingredient> ingredients = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Wybierz składniki: ");

        while (true) {
            System.out.println("1. Woda");
            System.out.println("2. Sok");
            System.out.println("3. Gotowe");
            System.out.print("Wybierz opcję: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // clear the buffer

            if (choice == 1) {
                ingredients.add(new Ingredient("Woda", "50ml"));
            } else if (choice == 2) {
                ingredients.add(new Ingredient("Sok", "100ml"));
            } else if (choice == 3) {
                break;
            } else {
                System.out.println("Nieprawidłowy wybór. Spróbuj ponownie.");
            }
        }

        return ingredients;
    }
}